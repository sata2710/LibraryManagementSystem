package com.lms.service;

import com.lms.model.Book;
import com.lms.model.Loan;
import com.lms.model.User;
import com.lms.repository.BookRepository;
import com.lms.repository.LoanRepository;
import com.lms.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;


@Service
public class LoanService {

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private UserRepository userRepository;

    // Borrow a book
    public Loan borrowBook(Long userId, Long bookId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Book book = bookRepository.findById(bookId).orElseThrow(() -> new RuntimeException("Book not found"));

        if (book.getAvailableCopies() <= 0) {
            throw new RuntimeException("No available copies of the book");
        }

        Loan loan = new Loan();
        loan.setUser(user);
        loan.setBook(book);
        loan.setBorrowDate(LocalDate.now());
        loan.setReturnDate(null); // Book hasn't been returned yet

        // Update book's available copies
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepository.save(book);

        return loanRepository.save(loan);
    }

    // Return a book
    public void returnBook(Long loanId) {
        Loan loan = loanRepository.findById(loanId).orElseThrow(() -> new RuntimeException("Loan not found"));
        Book book = loan.getBook();

        loan.setReturnDate(LocalDate.now());

        // Update book's available copies
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        bookRepository.save(book);

        loanRepository.save(loan);
    }

    // Create a loan (not typically used for borrow and return)
    public Loan createLoan(Loan loan) {
        return loanRepository.save(loan);
    }

    // Get all loans
    public List<Loan> getAllLoans() {
        return loanRepository.findAll();
    }

    // Get loan by ID
    public Loan getLoanById(Long id) {
        return loanRepository.findById(id).orElse(null);
    }

    // Update a loan
    public Loan updateLoan(Long id, Loan loanDetails) {
        Loan loan = loanRepository.findById(id).orElse(null);
        if (loan != null) {
            loan.setReturnDate(loanDetails.getReturnDate());
            return loanRepository.save(loan);
        }
        return null;
    }

    // Delete a loan
    public void deleteLoan(Long id) {
        loanRepository.deleteById(id);
    }
}
