package com.lms.service;

import com.lms.model.Fine;
import com.lms.repository.FineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FineService {

    @Autowired
    private FineRepository fineRepository;

    public Fine createFine(Fine fine) {
        return fineRepository.save(fine);
    }

    public List<Fine> getAllFines() {
        return fineRepository.findAll();
    }

    public Fine getFineById(Long id) {
        return fineRepository.findById(id).orElse(null);
    }

    public Fine updateFine(Long id, Fine fineDetails) {
        Fine fine = fineRepository.findById(id).orElse(null);
        if (fine != null) {
            fine.setAmount(fineDetails.getAmount());
            fine.setPaid(fineDetails.isPaid());
            return fineRepository.save(fine);
        }
        return null;
    }

    public void deleteFine(Long id) {
        fineRepository.deleteById(id);
    }
}
