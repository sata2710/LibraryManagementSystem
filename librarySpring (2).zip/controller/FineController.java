package com.lms.controller;

import com.lms.model.Fine;
import com.lms.service.FineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fines")
public class FineController {

    @Autowired
    private FineService fineService;

    @PostMapping
    public ResponseEntity<Fine> createFine(@RequestBody Fine fine) {
        return new ResponseEntity<>(fineService.createFine(fine), HttpStatus.CREATED);
    }

    @GetMapping
    public List<Fine> getAllFines() {
        return fineService.getAllFines();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Fine> getFineById(@PathVariable Long id) {
        Fine fine = fineService.getFineById(id);
        return fine != null ? new ResponseEntity<>(fine, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Fine> updateFine(@PathVariable Long id, @RequestBody Fine fineDetails) {
        Fine updatedFine = fineService.updateFine(id, fineDetails);
        return updatedFine != null ? new ResponseEntity<>(updatedFine, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFine(@PathVariable Long id) {
        fineService.deleteFine(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
