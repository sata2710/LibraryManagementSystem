package com.lms.controller;

public class UserControllerIntegrationTest {

}
